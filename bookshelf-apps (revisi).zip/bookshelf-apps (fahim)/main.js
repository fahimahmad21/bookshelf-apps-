const STORAGE_KEY = 'BOOKSHELF_APPS';
const SAVED_EVENT = 'saved-book';
const RENDER_EVENT = 'render-book';

let books = [];

document.addEventListener('DOMContentLoaded', function () {
    const submitForm = document.getElementById('inputBook');
    submitForm.addEventListener('submit', function (event) {
        event.preventDefault();
        addBook();
    });

    if (isStorageExist()) {
        loadDataFromStorage();
    }
});

function generateId() {
    return +new Date();
}

function generateBookObject(id, title, author, year, isCompleted) {
    return {
        id,
        title,
        author,
        year: parseInt(year),
        isCompleted
    }
}

function addBook() {
    const bookTitle = document.getElementById('inputBookTitle').value;
    const bookAuthor = document.getElementById('inputBookAuthor').value;
    const bookYear = document.getElementById('inputBookYear').value;
    const isCompleted = document.getElementById('inputBookIsComplete').checked;

    const generatedID = generateId();
    const bookObject = generateBookObject(generatedID, bookTitle, bookAuthor, bookYear, isCompleted);
    books.push(bookObject);

    document.dispatchEvent(new Event(RENDER_EVENT));
    saveData();
}

function isStorageExist() {
    if (typeof (Storage) === undefined) {
        alert('Browser kamu tidak mendukung local storage');
        return false;
    }
    return true;
}

function saveData() {
    if (isStorageExist()) {
        const parsed = JSON.stringify(books);
        localStorage.setItem(STORAGE_KEY, parsed);
        document.dispatchEvent(new Event(SAVED_EVENT));
    }
}

function loadDataFromStorage() {
    const serializedData = localStorage.getItem(STORAGE_KEY);
    let data = JSON.parse(serializedData);

    if (data !== null) {
        for (const book of data) {
            books.push(book);
        }
    }

    document.dispatchEvent(new Event(RENDER_EVENT));
}

function findBook(bookId) {
    for (const book of books) {
        if (book.id === bookId) {
            return book;
        }
    }
    return null;
}

function findBookIndex(bookId) {
    for (const index in books) {
        if (books[index].id === bookId) {
            return index;
        }
    }

    return -1;
}

function removeBook(bookId) {
    const bookIndex = findBookIndex(bookId);

    if (bookIndex === -1) return;

    books.splice(bookIndex, 1);
    document.dispatchEvent(new Event(RENDER_EVENT));
    saveData();
}

function undoBookFromCompleted(bookId) {
    const bookTarget = findBook(bookId);

    if (bookTarget == null) return;

    bookTarget.isCompleted = false;
    document.dispatchEvent(new Event(RENDER_EVENT));
    saveData();
}

function addBookToCompleted(bookId) {
    const bookTarget = findBook(bookId);

    if (bookTarget == null) return;

    bookTarget.isCompleted = true;
    document.dispatchEvent(new Event(RENDER_EVENT));
    saveData();
}

function makeBook(bookObject) {
    const {id, title, author, year, isCompleted} = bookObject;

    const textTitle = document.createElement('h3');
    textTitle.innerText = title;

    const textAuthor = document.createElement('p');
    textAuthor.innerText = `Penulis: ${author}`;

    const textYear = document.createElement('p');
    textYear.innerText = `Tahun: ${year}`;

    const container = document.createElement('article');
    container.classList.add('book_item');
    container.append(textTitle, textAuthor, textYear);
    container.setAttribute('id', `book-${id}`);

    const actionContainer = document.createElement('div');
    actionContainer.classList.add('action');

    if (isCompleted) {
        const undoButton = document.createElement('button');
        undoButton.classList.add('green');
        undoButton.innerText = 'Belum selesai di Baca';
        undoButton.addEventListener('click', function () {
            undoBookFromCompleted(id);
        });

        const trashButton = document.createElement('button');
        trashButton.classList.add('red');
        trashButton.innerText = 'Hapus buku';
        trashButton.addEventListener('click', function () {
            removeBook(id);
        });

        actionContainer.append(undoButton, trashButton);
    } else {
        const checkButton = document.createElement('button');
        checkButton.classList.add('green');
        checkButton.innerText = 'Selesai dibaca';
        checkButton.addEventListener('click', function () {
            addBookToCompleted(id);
        });

        const trashButton = document.createElement('button');
        trashButton.classList.add('red');
        trashButton.innerText = 'Hapus buku';
        trashButton.addEventListener('click', function () {
            removeBook(id);
        });

        actionContainer.append(checkButton, trashButton);
    }

    container.append(actionContainer);

    return container;
}

document.addEventListener(RENDER_EVENT, function () {
    const incompleteBookshelfList = document.getElementById('incompleteBookshelfList');
    const completeBookshelfList = document.getElementById('completeBookshelfList');

    incompleteBookshelfList.innerHTML = '';
    completeBookshelfList.innerHTML = '';

    for (const bookItem of books) {
        const bookElement = makeBook(bookItem);
        if (!bookItem.isCompleted) {
            incompleteBookshelfList.append(bookElement);
        } else {
            completeBookshelfList.append(bookElement);
        }
    }
});

document.addEventListener(SAVED_EVENT, function () {
    console.log(localStorage.getItem(STORAGE_KEY));
});

// Mendengarkan event submit pada form pencarian
document.getElementById('searchBook').addEventListener('submit', function(event) {
    event.preventDefault(); // Menghentikan aksi bawaan dari form
  
    // Mendapatkan kata kunci pencarian dari input
    const searchKeyword = document.getElementById('searchBookTitle').value.toLowerCase();
  
    // Menyaring buku berdasarkan kata kunci pencarian
    const searchResults = books.filter(function(book) {
      return book.title.toLowerCase().includes(searchKeyword); // Mencocokkan dengan judul buku
    });
  
    // Menampilkan hasil pencarian
    renderSearchResults(searchResults);
});
  
// Fungsi untuk menampilkan hasil pencarian
function renderSearchResults(results) {
    const searchResultsContainer = document.getElementById('searchResults');
  
    // Mengosongkan kontainer hasil pencarian sebelum menambahkan hasil baru
    searchResultsContainer.innerHTML = '';
  
    if (results.length === 0) {
      // Jika tidak ada hasil pencarian, tampilkan pesan bahwa tidak ada hasil
      const noResultMessage = document.createElement('p');
      noResultMessage.textContent = 'Tidak ditemukan buku yang sesuai dengan kata kunci pencarian.';
      searchResultsContainer.appendChild(noResultMessage);
    } else {
      // Jika ada hasil pencarian, tampilkan daftar buku yang sesuai
      const resultList = document.createElement('ul');
      results.forEach(function(book) {
        const listItem = document.createElement('li');
        listItem.textContent = book.title;
        resultList.appendChild(listItem);
      });
      searchResultsContainer.appendChild(resultList);
    }
}
  
// Fungsi untuk merender daftar buku pada rak
function renderBookshelf(books) {
    const bookshelfContainer = document.getElementById('bookshelf');
  
    // Mengosongkan rak buku sebelum menambahkan buku baru
    bookshelfContainer.innerHTML = '';
  
    if (books.length === 0) {
      // Jika tidak ada buku yang tersedia, tampilkan pesan bahwa rak kosong
      const emptyMessage = document.createElement('p');
      emptyMessage.textContent = 'Rak buku kosong.';
      bookshelfContainer.appendChild(emptyMessage);
    } else {
      // Jika ada buku yang tersedia, tampilkan daftar buku
      const bookList = document.createElement('ul');
      books.forEach(function(book) {
        const listItem = document.createElement('li');
        listItem.textContent = book.title;
        bookList.appendChild(listItem);
      });
      bookshelfContainer.appendChild(bookList);
    }
}
  
// Fungsi untuk memfilter buku berdasarkan judul pada rak
function filterBooksByTitle(titleKeyword) {
    const filteredBooks = books.filter(function(book) {
      return book.title.toLowerCase().includes(titleKeyword.toLowerCase());
    });
    renderBookshelf(filteredBooks);
}
  
// Mendengarkan event input pada kolom pencarian
document.getElementById('searchBookTitle').addEventListener('input', function(event) {
    const searchKeyword = event.target.value.trim(); // Mengambil kata kunci pencarian dan menghapus spasi ekstra
  
    if (searchKeyword === '') {
      // Jika kolom pencarian kosong, tampilkan semua buku pada rak
      renderBookshelf(books);
    } else {
      // Jika kolom pencarian tidak kosong, filter buku berdasarkan judul
      filterBooksByTitle(searchKeyword);
    }
});
  
// Inisialisasi render rak buku saat halaman dimuat
  document.addEventListener('DOMContentLoaded', function() {
    renderBookshelf(books);
});
  